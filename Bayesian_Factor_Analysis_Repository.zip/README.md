# Bayesian Factor Analysis Simulation
This repository contains R code and documentation for simulating and evaluating Maximum Likelihood and Bayesian estimation methods for factor analysis.

## Structure
- `simulate_factor_analysis.R`: R script for simulation and evaluation
- `lambda_metrics_summary.csv`: Summary of RMSE and Bias values across methods and sample sizes
- `comparison_plot.png`: Combined plot showing RMSE, Bias, and Computation Time
- `Lambda_Metrics_Simulation_Results.docx`: Simulation results report
- `LICENSE`: MIT License

## Authors
Mrs. S. Amirtha Rani Jagulin

## License
This project is licensed under the MIT License.

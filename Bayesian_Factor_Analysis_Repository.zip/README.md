# Bayesian vs MLE Factor Analysis
This repository contains R code, simulation data, and result summaries for the comparative analysis of Maximum Likelihood Estimation and Bayesian Estimation in Factor Analysis.

## Contents
- Simulation scripts for sample sizes n = 25, 300, 500
- Datasets used for evaluating factor loadings
- RMSE, Bias, Credible Interval, and Coverage Probability results
- Final report and figures

## Authors
Mrs. S. Amirtha Rani Jagulin, SRM Institute of Science and Technology

## License
This project is licensed under the MIT License.

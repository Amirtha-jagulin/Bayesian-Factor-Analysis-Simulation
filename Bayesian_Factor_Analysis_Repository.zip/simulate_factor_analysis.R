# R script to simulate data and compute metrics (RMSE, Bias, Coverage)
# Requires packages: MASS, MCMCpack, coda, dplyr

# Placeholder content. Replace with actual simulation code from your study.
print("Simulate factor analysis for n = 25, 300, 500...")
